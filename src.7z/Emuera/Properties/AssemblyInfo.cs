﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;



// アセンブリに関する一般情報は以下の属性セットをとおして制御されます。 
// アセンブリに関連付けられている情報を変更するには、
// これらの属性値を変更してください。
[assembly: AssemblyTitle("Emuera")]
[assembly: AssemblyDescription("v11+webp+test+私家版")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("Emuera")]
[assembly: AssemblyCopyright("Copyright (C) 2008- MinorShift, 妊）|дﾟ)の中の人")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// ComVisible を false に設定すると、このアセンブリ内の型は COM コンポーネントには 
// 参照不可能になります。COM からこのアセンブリ内の型にアクセスする場合は、 
// その型の ComVisible 属性を true に設定してください。
[assembly: ComVisible(false)]

// 次の GUID は、このプロジェクトが COM に公開される場合の、typelib の ID です
[assembly: Guid("7056c97a-adf8-4f46-a084-c293c8431d90")]

// アセンブリのバージョン情報は、以下の 4 つの値で構成されています:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
[assembly: AssemblyVersion("1.824.*")]
[assembly: AssemblyFileVersion("1.824.0.11")]
